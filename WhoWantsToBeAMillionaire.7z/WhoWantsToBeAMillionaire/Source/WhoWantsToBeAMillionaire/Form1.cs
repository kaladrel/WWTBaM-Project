﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WhoWantsToBeAMillionaire
{

    public partial class Form1 : Form
    {
        int i = 0;
        int voithia50 = 1;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {





        }

        private void button5_Click(object sender, EventArgs e)
        {
            i = i + 1;
            button5.Text = "NEXT";
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            if (i == 1)
            {
                button7.Text = "What's the capital city of Greece?";
                button1.Text = "Thessaloniki";
                button2.Text = "Athens";
                button3.Text = "Patra";
                button4.Text = "Larisa";
            }
            if (i == 2)
            {
                button7.Text = "Which NBA player is trying to surpass the record of 41 triple-doubles of Oscar Robertson on the current season?";
                button1.Text = "James Harden";
                button2.Text = "Anthoni Davis";
                button3.Text = "Giannis Antetokounmpo";
                button4.Text = "Russell Westbrook";
            }
            if (i == 3)
            {
                button7.Text = "Who is the developer of the popular videogame franchise 'Dark souls' ";
                button1.Text = "FromSoftware";
                button2.Text = "Ubisoft";
                button3.Text = "CD Projekt Red";
                button4.Text = "Rockstar North";
            }
            if (i == 4)
            {
                button7.Text = "What's the manufacturing node of the AMD's line-up of CPUs codenamed 'Ryzen'";
                button1.Text = "32 nanometers";
                button2.Text = "22 nanometers";
                button3.Text = "14 nanometers";
                button4.Text = "5 nanometers";
            }
            if (i == 5)
            {
                button7.Text = "The fastest man-made object to date is";
                button1.Text = "ISS";
                button2.Text = "Helios 2";
                button3.Text = "Apollo 11";
                button4.Text = "Buggati Veyron";
            }
            if (i == 6)
            {
                button7.Text = "Which country has the lowest natural elevation point";
                button1.Text = "Maldives";
                button2.Text = "Malta";
                button3.Text = "Afghanistan";
                button4.Text = "Bahrain";
            }
            if (i == 7)
            {
                button7.Text = "Who scored the last goal on the round of 16 in the match Barcelona - Paris saint germain with final score 6-1 ";
                button1.Text = "Sergio Ramos";
                button2.Text = "Luis Suarez";
                button3.Text = "Leonel Messi";
                button4.Text = "Sergio Roberto";
            }
            if (i == 8)
            {
                button7.Text = "How many known planets our solar system have?";
                button1.Text = "12";
                button2.Text = "8";
                button3.Text = "16";
                button4.Text = "9";
            }
            if (i == 9)
            {
                button7.Text = "How much blood is in the human body?";
                button1.Text = "5 litres";
                button2.Text = "2 litres";
                button3.Text = "7 litres";
                button4.Text = "20 litres";
            }
            if (i == 10)
            {
                button7.Text = "What is the most powerfull energetic object known in the universe?";
                button1.Text = "Singular star";
                button2.Text = "Black Hole";
                button3.Text = "The Sun";
                button4.Text = "Quasar";
            }
            if (i == 11)
            {
                button7.Text = "Who is the most expensive association football transfer?";
                button1.Text = "Oscar";
                button2.Text = "Luis Figo";
                button3.Text = "Paul Pogba";
                button4.Text = "Marcus Berg";
            }

            if (i > 11)
            {
                MessageBox.Show("Thank You For Playing!");
                button7.Text = "";
                button1.Text = "";
                button2.Text = "";
                button3.Text = "";
                button4.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (i == 0)
            {
                MessageBox.Show("Please press the start button");
            }
            if (i == 1)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 2)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 3)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 4)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 5)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 6)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 7)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 8)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 9)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 10)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 11)
            {
                MessageBox.Show("FALSE");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (i == 0)
            {
                MessageBox.Show("Please press the start button");
            }
            if (i == 1)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 2)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 3)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 4)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 5)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 6)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 7)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 8)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 9)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 10)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 11)
            {
                MessageBox.Show("FALSE");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (i == 0)
            {
                MessageBox.Show("Please press the start button");
            }
            if (i == 1)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 2)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 3)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 4)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 5)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 6)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 7)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 8)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 9)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 10)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 11)
            {
                MessageBox.Show("CORRECT!");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (i == 0)
            {
                MessageBox.Show("Please press the start button");
            }
            if (i == 1)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 2)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 3)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 4)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 5)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 6)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 7)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 8)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 9)
            {
                MessageBox.Show("FALSE");
            }
            if (i == 10)
            {
                MessageBox.Show("CORRECT!");
            }
            if (i == 11)
            {
                MessageBox.Show("FALSE");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (voithia50 == 1)
            {
                if (i == 1)
                {

                    button1.Enabled = false;
                    button1.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 2)
                {

                    button2.Enabled = false;
                    button2.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 3)
                {

                    button4.Enabled = false;
                    button4.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 4)
                {

                    button2.Enabled = false;
                    button2.Text = "";
                    button4.Enabled = false;
                    button4.Text = "";
                }
                if (i == 5)
                {

                    button1.Enabled = false;
                    button1.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 6)
                {

                    button4.Enabled = false;
                    button4.Text = "";
                    button2.Enabled = false;
                    button2.Text = "";
                }
                if (i == 7)
                {

                    button2.Enabled = false;
                    button2.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 8)
                {

                    button1.Enabled = false;
                    button1.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 9)
                {

                    button4.Enabled = false;
                    button4.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 10)
                {

                    button2.Enabled = false;
                    button2.Text = "";
                    button3.Enabled = false;
                    button3.Text = "";
                }
                if (i == 11)
                {

                    button2.Enabled = false;
                    button2.Text = "";
                    button4.Enabled = false;
                    button4.Text = "";
                }
                voithia50 = voithia50 - 1;
            }
            else
            {
                MessageBox.Show("You can use 50:50 only once per game");
            }
          
        }
        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit()
        ;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        }

        private void button9_Click(object sender, EventArgs e)
        {
            i = 0;
            voithia50 = 1;
            button5.Text = "START";
        }
    }
}
            
        
    
